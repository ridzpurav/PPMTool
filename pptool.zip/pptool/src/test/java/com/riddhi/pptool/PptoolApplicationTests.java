package com.riddhi.pptool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PptoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
